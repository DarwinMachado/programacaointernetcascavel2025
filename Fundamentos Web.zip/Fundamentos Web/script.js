let btEx1 = document.querySelector("#btEx1");
let resEx1 = document.querySelector("#resEx1");
btEx1.onclick = function () {
    let x = parseFloat(document.querySelector("#ex1x").value);
    let y = parseFloat(document.querySelector("#ex1y").value);
    let z = parseFloat(document.querySelector("#ex1z").value);

    if (isNaN(x) || isNaN(y) || isNaN(z) || x <= 0 || y <= 0 || z <= 0) {
        resEx1.innerText = "Informe três valores positivos.";
        return;
    }

    if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z){
            resEx1.innerText = "É um triângulo Equilátero.";
        } else if (x === y || x === z || y === z) {
            resEx1.innerText = "É um triângulo Isósceles.";
        } else {
            resEx1.innerText = "É um triângulo Escaleno.";
        }
    } else {
        resEx1.innerText = "Não forma um triângulo.";
    }
};

let btEx2 = document.querySelector("#btEx2");
let resEx2 = document.querySelector("#resEx2");
btEx2.onclick = function() {
    let peso = parseFloat(document.querySelector("#ex2peso").value);
    let altura =  parseFloat(document.querySelector("#ex2altura").value);

    if (isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0) {
        resEx2.innerText = "Informe peso e altura válidos.";
        return;
    }

    let imc = peso / (altura * altura);
    let classificacao = "";

    if (imc < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (imc < 25) {
        classificacao = "Peso normal";
    } else if (imc < 30) {
        classificacao = "Sobrepeso";
    } else if (imc < 35) {
        classificacao = "Obesidade grau 1";
    } else if (imc < 40) {
        classificacao = "Obesidade grau 2";
    } else {
        classificacao = "Obesidade grau 3";
    }

    resEx2.innerHTML = `IMC: ${imc.toFixed(2)}<br>${classificacao}`;
    
    };

    let btEx3 = document.querySelector("#btEx3");
    let resEx3 = document.querySelector("#resEx3");
    btEx3.onclick = function () {
        let ano = parseInt(document.querySelector("#ex3ano").value);
        let valor = parseFloat(document.querySelector("#ex3valor").value);

        if (isNaN(ano) || isNaN(valor) || ano <= 0 || valor <= 0) {
        resEx3.innerText = "Informe ano e valor válidos.";
        return;

        }
        let taxa = (ano < 1990) ? 0.01 : 0.015;
        let imposto = valor * taxa;

        resEx3.innerHTML = `Taxa aplicada: ${(taxa * 100).toFixed(1)}%<br>Imposto: R$ ${imposto.toFixed(2)}`;
    };

    let btEx4 = document.querySelector("#btEx4");
let resEx4 = document.querySelector("#resEx4");
btEx4.onclick = function () {
    let salario = parseFloat(document.querySelector("#ex4sal").value);
    let cargo = document.querySelector("#ex4cargo").value.trim().toLowerCase();

    if (isNaN(salario) || salario <= 0 || !cargo) {
        resEx4.innerText = "Informe salário e cargo válidos.";
        return;
    }
    let percentual;
    switch (cargo) {
        case "gerente":
            percentual = 0.10;
            break;
        case "engenheiro":
            percentual = 0.20;
            break;
        case "técnico":
        case "tecnico":
            percentual = 0.05;
            break;
        default:
            percentual = 0.40;
    }
    let novoSal = salario * (1 + percentual);
    let diferenca = novoSal - salario;

    resEx4.innerHTML = 
        `Salário antigo: R$ ${salario.toFixed(2)}<br>` +
        `Percentual de aumento: ${(percentual * 100).toFixed(0)}%<br>` +
        `Novo salário: R$ ${novoSal.toFixed(2)}<br>` +
        `Diferença: R$ ${diferenca.toFixed(2)}`;
};

let btEx5 = document.querySelector("#btEx5");
let resEx5 = document.querySelector("#resEx5");
btEx5.onclick = function () {
    let saldo = parseFloat(document.querySelector("#ex5saldo").value);
    if (isNaN(saldo) || saldo < 0) {
        resEx5.innerText = "Informe saldo médio válido.";
        return;
    }
    let credito;
    if (saldo < 500) {
        credito = 0;
    } else if (saldo < 1000) {
        credito = saldo * 0.10;
    } else if (saldo < 3000) {
        credito = saldo * 0.15;
    } else {
        credito = saldo * 0.20;
    }
    resEx5.innerHTML = `Saldo médio: R$ ${saldo.toFixed(2)}<br>Crédito: R$ ${credito.toFixed(2)}`;
};

let btEx6 = document.querySelector("#btEx6");
let resEx6 = document.querySelector("#resEx6");
btEx6.onclick = function () {
    let codigo = parseInt(document.querySelector("#ex6codigo").value);
    let qtd = parseInt(document.querySelector("#ex6qtd").value);
    if (isNaN(codigo) || isNaN(qtd) || qtd <= 0) {
        resEx6.innerText = "Informe código e quantidade válidos.";
        return;
    }
    let preco;
    switch (codigo) {
        case 100: preco = 1.20; break;
        case 101: preco = 1.30; break; 
        case 102: preco = 1.50; break; 
        case 103: preco = 1.20; break; 
        case 104: preco = 1.30; break; 
        case 105: preco = 1.00; break; 
        default:
            resEx6.innerText = "Código inválido.";
            return;
    }
    let total = preco * qtd;
    resEx6.innerHTML = `Item: Código ${codigo}<br>Quantidade: ${qtd}<br>Total: R$ ${total.toFixed(2)}`;
};

let btEx7 = document.querySelector("#btEx7");
let resEx7 = document.querySelector("#resEx7");
btEx7.onclick = function () {
    let preco = parseFloat(document.querySelector("#ex7preco").value);
    let cond = document.querySelector("#ex7cond").value;
    if (isNaN(preco) || preco <= 0) {
        resEx7.innerText = "Informe preço válido.";
        return;
    }
    let total;
    switch (cond) {
        case "a": 
            total = preco * 0.90;
            break;
        case "b": 
            total = preco * 0.85;
            break;
        case "c": 
            total = preco;
            break;
        case "d": 
            total = preco * 1.10;
            break;
        default:
            resEx7.innerText = "Condição inválida.";
            return;
    }
    resEx7.innerHTML = `Condição: ${cond.toUpperCase()}<br>Total a pagar: R$ ${total.toFixed(2)}`;
};

let btEx8 = document.querySelector("#btEx8");
let resEx8 = document.querySelector("#resEx8");
btEx8.onclick = function () {
    let nivel = parseInt(document.querySelector("#ex8nivel").value);
    let horas = parseInt(document.querySelector("#ex8horas").value);
    if (isNaN(nivel) || isNaN(horas) || horas < 0) {
        resEx8.innerText = "Informe nível e horas válidos.";
        return;
    }
    let valorHora;
    switch (nivel) {
        case 1: valorHora = 12; break;
        case 2: valorHora = 17; break;
        case 3: valorHora = 25; break;
        default:
            resEx8.innerText = "Nível inválido.";
            return;
    }

    let salario = valorHora * horas * 4.5;
    resEx8.innerHTML = `Valor por hora: R$ ${valorHora.toFixed(2)}<br>` +
                       `Horas/semana: ${horas}<br>` +
                       `Salário mensal: R$ ${salario.toFixed(2)}`;
};


