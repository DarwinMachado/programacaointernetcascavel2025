// Mostrar botão "Voltar ao Topo"
window.addEventListener('scroll', () => {
    const btn = document.getElementById('back-to-top');
    if (window.scrollY > 200) {
        btn.style.display = 'block';
    } else {
        btn.style.display = 'none';
    }
});

document.getElementById('back-to-top').addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Dados do Quiz
const quizData = [
    {
        question: "O que é phishing?",
        options: [
            "Ato de pescar dados físicos.",
            "Golpe que engana usuários para obter dados pessoais.",
            "Software para acelerar downloads."
        ],
        correct: 1
    },
    {
        question: "Por que usar autenticação em dois fatores?",
        options: [
            "Para ter acesso mais rápido.",
            "Para duplicar sua senha.",
            "Para aumentar a segurança ao acessar uma conta."
        ],
        correct: 2
    },
    {
        question: "O que é uma senha segura?",
        options: [
            "123456",
            "Seu nome e data de nascimento",
            "Uma combinação de letras, números e símbolos"
        ],
        correct: 2
    },
    {
        question: "Qual das opções é uma boa prática de segurança?",
        options: [
            "Clicar em links de promoções desconhecidas.",
            "Usar a mesma senha para todos os sites.",
            "Atualizar seus dispositivos regularmente."
        ],
        correct: 2
    }
];

let currentQuestion = 0;
let score = 0;

const questionEl = document.getElementById('question');
const optionsEl = document.getElementById('options');
const nextButton = document.getElementById('next');
const resultEl = document.getElementById('result');

// Carregar pergunta
function loadQuestion() {
    const currentQuiz = quizData[currentQuestion];
    questionEl.innerText = currentQuiz.question;
    optionsEl.innerHTML = "";
    nextButton.style.display = "none";

    currentQuiz.options.forEach((option, index) => {
        const btn = document.createElement('button');
        btn.innerText = option;
        btn.classList.add('option-btn');
        btn.addEventListener('click', () => selectOption(index));
        optionsEl.appendChild(btn);
    });
}

// Selecionar resposta
function selectOption(selectedIndex) {
    const currentQuiz = quizData[currentQuestion];
    const buttons = document.querySelectorAll('.option-btn');

    buttons.forEach((btn, index) => {
        btn.disabled = true;
        if (index === currentQuiz.correct) {
            btn.classList.add('btn-success');
        } else if (index === selectedIndex) {
            btn.classList.add('btn-danger');
        }
        btn.style.color = 'white';
    });

    if (selectedIndex === currentQuiz.correct) {
        score++;
    }

    nextButton.style.display = "block";
}

// Avançar pergunta
nextButton.addEventListener('click', () => {
    currentQuestion++;
    if (currentQuestion < quizData.length) {
        loadQuestion();
    } else {
        showResult();
    }
});

function showResult() {
    questionEl.innerText = "Quiz finalizado!";
    optionsEl.innerHTML = "";
    nextButton.style.display = "none";
    resultEl.style.display = "block";
    resultEl.innerText = `Você acertou ${score} de ${quizData.length} perguntas.`;
}

loadQuestion();

// Animações de seção
const sections = document.querySelectorAll("section");
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("visible");
        }
    });
}, {
    threshold: 0.2
});
sections.forEach((section) => observer.observe(section));

// Abas do conteúdo principal
function mostrarAba(abaId, grupo) {
    const todasAbas = document.querySelectorAll(`#secao-${grupo} .aba`);
    const titulo = document.getElementById(`titulo-${grupo}`);
    const abaAtual = document.getElementById(`aba-${grupo}-${abaId}`);

    if (!abaAtual) return;

    if (abaAtual.style.display === "block") {
        abaAtual.style.display = "none";
        if (titulo) titulo.innerText = "";
        return;
    }

    todasAbas.forEach(aba => aba.style.display = "none");
    abaAtual.style.display = "block";

    if (titulo) {
        if (abaId === "boas-praticas") titulo.innerText = "Boas Práticas de Segurança";
        if (abaId === "senhas") titulo.innerText = "Senhas Fortes";
        if (abaId === "celular") titulo.innerText = "Segurança no Celular";
        if (abaId === "golpes") titulo.innerText = "Principais Golpes Online";
        if (abaId === "redes") titulo.innerText = "Redes Sociais";
        if (abaId === "navegacao") titulo.innerText = "Navegação Segura na Internet";
        if (abaId === "ferramentas") titulo.innerText = "Ferramentas Úteis";
    }
}

// Funções para abrir e voltar do quiz
function abrirQuiz() {
    document.getElementById('conteudo-principal').style.display = 'none';
    document.getElementById('quiz').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function voltarConteudo() {
    document.getElementById('quiz').style.display = 'none';
    document.getElementById('conteudo-principal').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
