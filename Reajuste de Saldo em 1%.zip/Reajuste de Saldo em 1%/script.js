function reajustar() {
    const saldo = parseFloat(document.getElementById("saldo").value);

    if (isNaN(saldo)) {
        document.getElementById("resultado").innerText = "Informe um valor válido.";
        return;
    }

    const reajuste = saldo * 0.01;
    const saldoReajustado = saldo + reajuste;

    document.getElementById("resultado").innerText = "Saldo com reajuste: R$" + saldoReajustado.toFixed(2);
}