function calcular() {
    const valorQuilo = parseFloat(document.getElementById("valorQuilo").value);
    const quantidade = parseFloat(document.getElementById("quantidadedeQuilos").value);

    if (isNaN(valorQuilo) || isNaN(quantidade)) {
        document.getElementById("resultado").innerText = "Preencha os dois campos corretamente.";
        return;
    }

    const total = valorQuilo * quantidade;
    document.getElementById("resultado").innerText = "Valor a pagar: R$" + total.toFixed(2);
}