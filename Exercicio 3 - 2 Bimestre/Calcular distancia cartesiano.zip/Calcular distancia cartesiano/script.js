function calcularDistancia() {
    const x1 = parseFloat(document.getElementById("x1").value);
    const y1 = parseFloat(document.getElementById("y1").value);
    const x2 = parseFloat(document.getElementById("x2").value);
    const y2 = parseFloat(document.getElementById("y2").value);

    if ([x1, y1, x2, y2].some(isNaN)) {
        document.getElementById("resultado").innerText = "Preencha as coordenadas corretamente.";
        return;
    }

    const distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

    document.getElementById("resultado").innerText = `a distancia entre os pontos é: ${distancia.toFixed(2)}`;
}