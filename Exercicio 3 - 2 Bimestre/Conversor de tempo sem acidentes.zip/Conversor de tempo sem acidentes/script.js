function converterTempo() { 
    const totalDias = parseInt(document.getElementById("dias").value);

    if (isNaN(totalDias) || totalDias < 0) {
        document.getElementById("resultado").innerText = "Informe um número válido de dias.";
        return;
    }

    const anos = Math.floor(totalDias / 360);
    const meses = Math.floor(totalDias % 360) / 30;
    const dias = totalDias % 30;

    document.getElementById("resultado").innerText = `tempo sem acidentes: ${anos} ano(s), ${meses} Mês(es) e ${dias} dia(s).`;

}