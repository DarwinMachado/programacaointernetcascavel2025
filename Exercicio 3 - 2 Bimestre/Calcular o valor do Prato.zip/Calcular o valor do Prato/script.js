function calcularPeso() {
    const peso = parseFloat(document.getElementById("peso").value);
    const precoPorQuilo = 12.00;

    if (isNaN(peso) || peso <= 0) {
        document.getElementById("resultado").innerText = "Informe um peso válido.";
        return;
    }

    const total = peso * precoPorQuilo;
    document.getElementById("resultado").innerText = `Valor a pagar: R$ ${total.toFixed(2)}`;
}