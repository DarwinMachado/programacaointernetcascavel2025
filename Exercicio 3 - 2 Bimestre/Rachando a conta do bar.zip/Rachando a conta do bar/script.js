let inputConta = document.querySelector("#inputConta");
let h3Resultado = document.querySelector("#h3Resultado");
let btCalcular = document.querySelector("#btCalcular");

function dividirConta() {
    let conta = parseFloat(inputConta.value);

    if (isNaN(conta) || conta <= 0) {
        h3Resultado.innerText = "Informe um valor válido para a conta.";
        return;
    }

    let carlos = Math.floor(conta / 3);
    let andre = Math.floor(conta / 3);
    let felipe = conta - carlos - andre;

    h3Resultado.innerHTML =
    "Carlos deve pagar: R$" + carlos.toFixed(2) + "<br>" +
    "André deve pagar: R$" + andre.toFixed(2) + "<br>" +
    "Felipe deve pagar: R$" + felipe.toFixed(2);
}

btCalcular.onclick = function () {
    dividirConta();
}