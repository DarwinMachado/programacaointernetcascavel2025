function calcularLitros() {
    const preco = parseFloat(document.getElementById("precoLitro").value);
    const valor = parseFloat(document.getElementById("valorPago").value);

    if (isNaN(preco) || isNaN(valor) || preco <= 0 || valor <= 0) { 
        document.getElementById("resultado").innerText = "Informe valores válidos para o preco e o valor pago.";
        return;
    }

    const litros = valor / preco;
    document.getElementById("resultado").innerText = `Você conseguiu abastecer ${litros.toFixed(2)} litros de gasolina.`;
}