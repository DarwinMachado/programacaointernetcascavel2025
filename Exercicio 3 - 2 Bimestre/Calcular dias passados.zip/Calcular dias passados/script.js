function calcularDias() {
    const dia = parseInt(document.getElementById("dia").value);
    const mes = parseInt(document.getElementById("mes").value);

    if (isNaN(dia) || isNaN(mes) || dia < 1 || dia > 30 || mes < 1 || mes > 12) {
        document.getElementById("resultado").innerText = "Por favor, informe um dia entre 1 e 30 e um mêsentre 1 e 12.";
        return;
    }

    const diasTotais = (mes - 1) * 30 + dia;

    document.getElementById("resultado").innerText = `Já se passaram ${diasTotais}dias desde o início do ano.`;
}