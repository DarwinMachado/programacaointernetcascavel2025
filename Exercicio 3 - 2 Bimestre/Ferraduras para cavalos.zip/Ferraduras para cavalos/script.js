function  calcularFerraduras() {
    const cavalos = parseFloat(document.getElementById("cavalos").value);

    if (isNaN(cavalos) || cavalos <= 0) {
        document.getElementById("resultado").innerText = "Informe um númeor válido de cavalos.";
        return;
    }

    const ferraduras = cavalos * 4;
    
    document.getElementById("resultado").innerHTML = ` Serão necessárias <strong>${ferraduras}</strong> ferraduras para equipar ${cavalos} cavalo(s).
    `;
}