let inputSalario = document.querySelector("#inputSalario");
let h3Resultado = document.querySelector("#h3Resultado");
let btCalcular = document.querySelector("#btCalcular");

function calcularSalario() {
    let salario = Number(inputSalario.value);

    let comAumento = salario * 1.15;
    let salarioFinal  = comAumento * 0.92;

    h3Resultado.innerHTML = 
    "Salário Inicial: R$" + salario.toFixed(2) + "<br>" +
    "Com aumento de 15%: R$" + comAumento.toFixed(2) + "<br>" +
    "Com desconto de 8%: R$" + salarioFinal.toFixed(2);

}

btCalcular.onclick = function() {
    calcularSalario();
}