let inputRaio = document.querySelector("#inputRaio");
let h3Resultado = document.querySelector("#h3Resultado");
let btCalcular = document.querySelector("#btCalcular");

function CalcularAreaPizza() {
    let raio = parseFloat(inputRaio.value);

    if (isNaN(raio) || raio <= 0) { 
    h3Resultado.innerText = "Informe um valor válido para o raio.";
    return;
}

const pi = 3.14;
let area = pi * raio * raio;

h3Resultado.innerText = "Área da Pizza:" + area.toFixed(2) + "cm²";

}

btCalcular.onclick = function () {
    CalcularAreaPizza();
}