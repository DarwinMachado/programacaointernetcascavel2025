function calcularArrecadacao() {
    const paes = parseFloat(document.getElementById("pães").value);
    const broas = parseFloat(document.getElementById("broas").value);

    if (isNaN(paes) || isNaN(broas) || paes < 0 || broas < 0) { 
    document.getElementById("resultado").innerText = "Informe valores válidos para pães e broas.";
    return;

    }

    const valorPaes = paes * 0.12;
    const valorBroas = broas * 0.50;
    const total = valorPaes + valorBroas;
    const poupanca = total * 0.10;

    const resultado = ` Total arrecadado: ${total.toFixed(2)}<br>
    Valor a ser guardado na poupança (10%): R$ ${poupanca.toFixed(2)}
    `;

    document.getElementById("resultado").innerHTML = resultado;

}