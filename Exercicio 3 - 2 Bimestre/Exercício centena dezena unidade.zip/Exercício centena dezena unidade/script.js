let inputNumero = document.querySelector("#inputNumero");
let h3Resultado = document.querySelector("#h3Resultado");
let btCalcular = document.querySelector("#btCalcular");

function SepararDigitos() {
    let numero = parseInt(inputNumero.value);
    
    if (isNaN(numero) || numero < 0 || numero > 999) {
        h3Resultado.innerText = "Informe um número entre 0 e 999.";
        return;
    }

    let centena = Math.floor(numero / 100);
    let dezena = Math.floor((numero % 100) / 10);
    let unidade = numero % 10;

    h3Resultado.innerHTML =
    "CENTENA = " + centena + "<br>" +
    "DEZENA = " + dezena + "<br>"+
    "UNIDADE = " + unidade; 
}

btCalcular.onclick = function () {
    SepararDigitos();
}