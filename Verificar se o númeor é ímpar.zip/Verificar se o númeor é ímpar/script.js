function verificarImpar () {
    const numero = parseFloat(document.getElementById("numero").value);

    if (isNaN(numero)) {
        document.getElementById("resultado").innerText = "informe um número válido.";
        return;
    }

    if (numero % 2 !== 0) {
        document.getElementById("resultado").innerText = "O número é ímpar.";
    } else {
        document.getElementById("resultado").innerText = "O número não é ímpar.";
    }
}