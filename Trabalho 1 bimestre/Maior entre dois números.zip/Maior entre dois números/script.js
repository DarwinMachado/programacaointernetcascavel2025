function comparar() {
    const v1 = parseFloat(document.getElementById("valor1").value);
    const v2 = parseFloat(document.getElementById("valor2").value);

    if (isNaN(v1) || isNaN(v2)) {
        document.getElementById("resultado").innerText = "Preencha os dois campos com números válidos.";
        return;
    }

    let mensagem;

    if (v1 > v2) {
        mensagem = "O maior valor é:" + v1;
    } else if (v2 > v1) {
        mensagem = "O maior valor é:" + v2;
    } else {
        mensagem = "Os dois valores são iguais.";
    }

    document.getElementById("resultado").innerText = mensagem;
}