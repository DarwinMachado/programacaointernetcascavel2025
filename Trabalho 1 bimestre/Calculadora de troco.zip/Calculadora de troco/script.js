function calcularTroco() {
    let valorPago = parseFloat(document.getElementById("valorPago").value);
    let precoProduto = parseFloat(document.getElementById("precoProduto").value);
    let resultado = document.getElementById("resultado");

    if (isNaN(valorPago) || isNaN(precoProduto)) {
        resultado.textContent = "Por favor, insira valores válidos.";
    }   else if (valorPago < precoProduto) {
        resultado.textContent = "Valor pago insuficiente!";
    }   else {
        let troco = valorPago - precoProduto;
        resultado.textContent = "troco: R$" + troco.toFixed(2);
    }
}