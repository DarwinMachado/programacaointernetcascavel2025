function encontrarMenor() {
    const v1 = parseFloat(document.getElementById("v1").value);
    const v2 = parseFloat(document.getElementById("v2").value);
    const v3 = parseFloat(document.getElementById("v3").value);
    const v4 = parseFloat(document.getElementById("v4").value);

    if ([v1, v2, v3, v4].some(isNaN)) {
        document.getElementById("resultado").innerText = "Preencha todos os campos com números válidos.";
        return;
    }

    const menor = Math.min(v1, v2, v3, v4);
    document.getElementById("resultado").innerText = "O menor valor é:" + menor;
}