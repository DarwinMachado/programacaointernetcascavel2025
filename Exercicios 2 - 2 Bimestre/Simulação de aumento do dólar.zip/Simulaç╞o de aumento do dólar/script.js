function calcularAumentos() {
  const cotacao = parseFloat(document.getElementById("cotacao").value);

  if (isNaN(cotacao) || cotacao <= 0) {
    document.getElementById("resultado").innerText = "Informe uma cotação válida.";
    return;
  }

  const aumento1 = cotacao * 1.01;
  const aumento2 = cotacao * 1.02;
  const aumento5 = cotacao * 1.05;
  const aumento10 = cotacao * 1.10;

  const resultado = `
    Cotação atual: R$ ${cotacao.toFixed(2)}<br><br>
    Com aumento de 1%: R$ ${aumento1.toFixed(2)}<br>
    Com aumento de 2%: R$ ${aumento2.toFixed(2)}<br>
    Com aumento de 5%: R$ ${aumento5.toFixed(2)}<br>
    Com aumento de 10%: R$ ${aumento10.toFixed(2)}
  `;

  document.getElementById("resultado").innerHTML = resultado;
}
