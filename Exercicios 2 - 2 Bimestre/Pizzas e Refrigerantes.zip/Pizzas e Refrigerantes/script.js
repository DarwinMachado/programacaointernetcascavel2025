function calcularPedido() {

    const sabor1 = document.getElementById("sabor1").value.trim();
    const sabor2 = document.getElementById("sabor2").value.trim();
    const sabor3 = document.getElementById("sabor3").value.trim();
    const sabor4 = document.getElementById("sabor4").value.trim();
    const refrigerantes = parseInt(document.getElementById("refrigerantes").value);

    if (!sabor1 || !sabor2 || !sabor3 || !sabor4 || isNaN(refrigerantes)) {
        document.getElementById("resultado").innerText = "Preencha todos os sabores e a quantidade de refrigerantes corretamente.";
        return;
    }

    const precoPizza = 12;
    const precoRefri = 7;
    const total = (4 * precoPizza) + (refrigerantes * precoRefri);

    const resultado = `
    Sabores escolhidos:<br>
    - ${sabor1}<br>
    - ${sabor2}<br>
    - ${sabor3}<br>
    - ${sabor4}<br><br>
    Refrigerantes: ${refrigerantes}<br>
    <strong>Total a pagar: R$ ${total.toFixed(2)}</strong>
    `;

    document.getElementById("resultado").innerHTML = resultado;

}